//
//  ViewController.swift
//  TextRecognition
//
//  Created by Bohdan Luchyshyn on 28.03.2022.
//
import Vision
import Photos
import PhotosUI
import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var imagePicker = UIImagePickerController()
    //var selectedUIImage : UIImage?
    
    @IBAction func copyLabelText() {
        UIPasteboard.general.string = label.text
    }
    
  @IBAction  func didTapButton() {
    imagePicker.delegate = self
    imagePicker.sourceType = .photoLibrary
    imagePicker.allowsEditing = false
    present(imagePicker, animated: true)
    }
    
    /*func loadAndRecognize(){
        guard let selectedUIImage = selectedUIImage else {return}
        recognizeText (image: selectedUIImage)
    }*/
    
    private func recognizeText(image: UIImage?){
        guard let cgImage = image?.cgImage else {return}
        
        //Handle
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        
        //Request
        let request = VNRecognizeTextRequest{[weak self] request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation],
                  error == nil else {
                return
            }
            
            let text = observations.compactMap({
                $0.topCandidates(1).first?.string
            }).joined(separator: ", ")
            
            DispatchQueue.main.async {
                self?.label.text = text
            }
        }
        
        //Process request
        do {
            try handler.perform([request])
        }
        catch{
            label.text = "\(error)"
        }
    }

    
   
    @IBOutlet var label: UILabel!
  
    @IBOutlet var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = self.view.bounds
        gradientLayer.colors = [UIColor.blue.cgColor, UIColor.yellow.cgColor]
        
        self.view.layer.insertSublayer(gradientLayer, at: 0)
        
      //  view.addSubview(label)
      //  view.addSubview(imageView)
        
        
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imageView.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        recognizeText(image: imageView.image)
        imagePicker.dismiss(animated: true)
    }

}

